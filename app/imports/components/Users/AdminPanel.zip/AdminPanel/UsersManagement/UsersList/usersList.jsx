import React from 'react';
import Avatar from 'material-ui/Avatar';
import Subheader from 'material-ui/Subheader';
import { List, ListItem, makeSelectable } from 'material-ui/List';
import { PropTypes } from 'prop-types';
// import DialogExampleSimple from './setAdmin.jsx';
import { xDD } from './setAdmin.jsx';
import Dialog from 'material-ui/Dialog';

console.log(xDD);

export default class UsersList extends React.Component {

    constructor(props) {
        super(props);
        this.SelectableList = makeSelectable(List);
        this.handleChange = this.handleChange.bind(this);
        this.users = props.users;
        this.callMethod = props.callMethod;
        this.state = { value: this.users.count() };
        this.user = this.users.fetch()[this.state.value - 1];
        this.items = [];
        for (let i = 1; i <= this.users.count(); i += 1) { // mapa
            this.items.push(
                <ListItem
                    value={1}
                    primaryText={this.users.fetch()[i - 1].services.github.username} // to change !!
                    key={`a${i}`}
                    leftAvatar={<Avatar
                        src="http://www.clker.com/cliparts/3/V/U/m/W/U/admin-button-icon-md.png"
                    />}
                    nestedItems={[
                        <ListItem
                            value={2}
                            primaryText="Set admin"
                            leftAvatar={<i>xD</i>}
                            key={i}
                            // onClick={() => actions.setAdmin(this.users.fetch()[i - 1])}
                        />,
                    ]}
                />,
                );
        }
    }


    handleChange(event, index, _value) {
        this.setState({ value: _value });
        this.state.value = _value;
        this.user = this.users.fetch()[this.state.value - 1];
    }
    render() {
        return (
            <div>
                <xDD />
                <this.SelectableList defaultValue={3}>
                    <Subheader>Users</Subheader>
                    {this.items}
                </this.SelectableList>
            </div>
        );
    }
}

UsersList.propTypes = {
    users: PropTypes.arrayOf(Array),
    callMethod: PropTypes.func,
};
