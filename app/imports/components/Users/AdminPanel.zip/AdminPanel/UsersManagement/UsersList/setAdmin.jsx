import { Meteor } from 'meteor/meteor';
import React from 'react';
import Dialog from 'material-ui/Dialog';

const callMethod = (nameOfMethod, userId) => Meteor.call(nameOfMethod, userId);

const setAdmin = (user) => {
    if (!user.isAdmin) {
        callMethod('setAdmin', user._id);
    } else {
        callMethod('remAdmin', user._id);
    }
};

const xDD = () => (
    <Dialog
        title="Add post"
        open
    >dsadsadasdasd </Dialog>);

const actions = {
    setAdmin,
};

export { xDD };
export { actions };

